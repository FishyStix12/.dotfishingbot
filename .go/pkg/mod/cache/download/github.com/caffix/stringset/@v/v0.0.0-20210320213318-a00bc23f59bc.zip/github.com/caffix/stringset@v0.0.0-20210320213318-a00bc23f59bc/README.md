# String Set

[![Go Report](https://goreportcard.com/badge/github.com/caffix/stringset)](https://goreportcard.com/report/github.com/caffix/stringset)
[![Follow on Twitter](https://img.shields.io/twitter/follow/jeff_foley.svg?logo=twitter)](https://twitter.com/jeff_foley)

## Contributors

* [Anthony Rhodes](https://github.com/fork-while-fork) aka `fork-while-fork`
  [![Follow on Twitter](https://img.shields.io/twitter/follow/fork_while_fork.svg?logo=twitter)](https://twitter.com/fork_while_fork)

## Licensing [![License](https://img.shields.io/github/license/caffix/stringset)](https://www.apache.org/licenses/LICENSE-2.0)

This program is free software: you can redistribute it and/or modify it under the terms of the [Apache license](LICENSE). Any contributions are Copyright © by Jeff Foley 2017-2021.
