// Package extensions implements various helper addons for Colly
package extensions
