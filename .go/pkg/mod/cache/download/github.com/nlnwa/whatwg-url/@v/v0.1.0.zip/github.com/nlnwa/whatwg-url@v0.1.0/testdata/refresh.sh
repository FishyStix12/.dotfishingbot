#!/usr/bin/env bash

curl -O https://raw.githubusercontent.com/web-platform-tests/wpt/master/url/resources/setters_tests.json
curl -O https://raw.githubusercontent.com/web-platform-tests/wpt/master/url/resources/urltestdata.json
