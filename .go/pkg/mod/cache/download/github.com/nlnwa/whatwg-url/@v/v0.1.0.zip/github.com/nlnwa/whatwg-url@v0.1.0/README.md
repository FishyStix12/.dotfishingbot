# whatwg-url
WHATWG conformant url parser for the Go language

This is a work in progress and the API is not stable yet
