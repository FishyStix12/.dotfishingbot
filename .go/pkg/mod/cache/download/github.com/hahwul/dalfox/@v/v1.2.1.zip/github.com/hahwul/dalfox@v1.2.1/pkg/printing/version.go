package printing

const VERSION = "v1.2.0"
