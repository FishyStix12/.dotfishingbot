/*
Code by @hahwul
Happy hacking :D
*/
package main

import "github.com/hahwul/dalfox/cmd"

func main() {
	cmd.Execute()
}
